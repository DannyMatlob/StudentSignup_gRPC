package edu.sjsu.cs158a.hello;

import edu.sjsu.cs158a.hello.Messages.CodeRequest;
import edu.sjsu.cs158a.hello.Messages.RegisterRequest;
import io.grpc.ManagedChannel;
import io.grpc.ManagedChannelBuilder;
import io.grpc.ServerBuilder;
import io.grpc.StatusRuntimeException;
import io.grpc.stub.StreamObserver;
import picocli.CommandLine;
import picocli.CommandLine.Command;
import picocli.CommandLine.Parameters;

import java.io.IOException;
import java.text.MessageFormat;
import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.atomic.AtomicInteger;
@Command
public class Main {
    @Command
    int add(@Parameters(paramLabel = "hostPort") String hostPort,
            @Parameters(paramLabel = "a") int a,
            @Parameters(paramLabel = "b") int b) {
        try {
            ManagedChannel channel = ManagedChannelBuilder.forTarget(hostPort).usePlaintext().build();
            var stub = AddExampleGrpc.newBlockingStub(channel);
            var request = Messages.AddExampleRequest.newBuilder().setA(a).setB(b).build();
            var rsp = stub.add(request);
            System.out.println(rsp.getResult());
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
            System.out.println("problem communicating with " + hostPort);
        }
        return 0;
    }
    @Command
    int requestCode(@Parameters(paramLabel = "hostPort") String hostPort,
                    @Parameters(paramLabel = "course") String course,
                    @Parameters(paramLabel = "ssid") int ssid) {
        try {
            ManagedChannel channel = ManagedChannelBuilder.forTarget(hostPort).usePlaintext().build();
            var stub = HelloGrpc.newBlockingStub(channel);
            var request = Messages.CodeRequest.newBuilder().setCourse(course).setSsid(ssid).build();
            var rsp = stub.requestCode(request);
            int errorCode = rsp.getRc();
            if (errorCode==0) {
                System.out.println("request successful");
            } else if (errorCode==1) {
                System.out.println("invalid course");
            } else if (errorCode==2) {
                System.out.println("invalid id");
            }
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
            System.out.println("problem communicating with " + hostPort);
        }
        return 0;
    }

    @Command
    int register(@Parameters(paramLabel = "hostPort") String hostPort,
                 @Parameters(paramLabel = "addcode") int addcode,
                 @Parameters(paramLabel = "ssid") int ssid,
                 @Parameters(paramLabel = "name") String name) {
        try {
            ManagedChannel channel = ManagedChannelBuilder.forTarget(hostPort).usePlaintext().build();
            var stub = HelloGrpc.newBlockingStub(channel);
            var request = Messages.RegisterRequest.newBuilder().setAddCode(addcode).setSsid(ssid).setName(name).build();
            var rsp = stub.register(request);
            int errorCode = rsp.getRc();
            if (errorCode==0) {
                System.out.println("registration successful");
            } else if (errorCode==1) {
                System.out.println("invalid code");
            } else if (errorCode==2) {
                System.out.println("code does not match id");
            }
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
            System.out.println("problem communicating with " + hostPort);
        }
        return 0;
    }

    @Command
    int listStudents(@Parameters(paramLabel = "hostPort") String hostPort,
             @Parameters(paramLabel = "course") String course) {
        try {
            ManagedChannel channel = ManagedChannelBuilder.forTarget(hostPort).usePlaintext().build();
            var stub = HelloGrpc.newBlockingStub(channel);
            var request = Messages.ListRequest.newBuilder().setCourse(course).build();
            var rsp = stub.list(request);
            for (RegisterRequest rr : rsp.getRegisterationsList()) {
                System.out.println(rr.getAddCode() + " " + rr.getSsid() + " " + rr.getName());
            }
        } catch (StatusRuntimeException e) {
            e.printStackTrace();
            System.out.println("problem communicating with " + hostPort);
        }
        return 0;
    }

    @Command
    int server(@Parameters(paramLabel = "port") int port) throws InterruptedException {
        class AddExampleImpl extends AddExampleGrpc.AddExampleImplBase {
            int total = 0;
            @Override
            public void add(Messages.AddExampleRequest request,StreamObserver<Messages.AddExampleResponse> responseObserver) {
                var a = request.getA();
                var b = request.getB();
                var sum = a + b;
                int myTotal;
                synchronized (this) {
                    total += sum;
                    myTotal = total;
                }
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                var response = Messages.AddExampleResponse.newBuilder()
                        .setResult(MessageFormat.format("{0} + {1} = {2} total {3}", a, b, sum, myTotal))
                        .build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();
            }
            }
        class HelloImpl extends HelloGrpc.HelloImplBase {
            boolean isValidSsid(int n) {
                if (n >= 100000 && n <= 90000000) return true;
                return false;
            }
            HashSet<String> validCourses = new HashSet<>(Arrays.asList("CS158A", "CS158B"));
            AtomicInteger addCounter = new AtomicInteger(1);
            ConcurrentHashMap<Integer, CodeRequest> request_addcode_map = new ConcurrentHashMap<>();
            ConcurrentHashMap<String, List<RegisterRequest>> course_regrequest_map = new ConcurrentHashMap<>();
            @Override
            public void requestCode(Messages.CodeRequest request, StreamObserver<Messages.CodeResponse> responseObserver) {
                var responseBuilder = Messages.CodeResponse.newBuilder();

                var course = request.getCourse();
                var ssid = request.getSsid();
                responseBuilder.setRc(2);
                //Check valid ssid
                if (!isValidSsid(ssid) || request_addcode_map.containsValue(request)) {
                    System.out.println("invalid ssid :" +  ssid + ", " + course);
                    responseBuilder.setRc(2);
                } else if (!validCourses.contains(course)) { //Check valid course
                    System.out.println("invalid course for ssid and course: " +  ssid + ", " + course);
                    responseBuilder.setRc(1);
                } else { //Fulfill request
                    System.out.println("Handling new addcode for ssid and course: " +  ssid + ", " + course);
                    int addCode = addCounter.getAndAdd(1);
                    System.out.println("handing out add code: " + addCode);
                    request_addcode_map.put(addCode, request);
                    responseBuilder.setAddcode(addCode);
                    responseBuilder.setRc(0);
                }

                //Build and send response
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

                var response = responseBuilder.build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();
            }
            @Override
            public void register(Messages.RegisterRequest request, StreamObserver<Messages.RegisterResponse> responseObserver) {
                var responseBuilder = Messages.RegisterResponse.newBuilder();

                var addCode = request.getAddCode();
                var ssid = request.getSsid();
                var name = request.getName();


                if (!request_addcode_map.containsKey(addCode)) {
                    //if Addcode not generated by server, return error
                    System.out.println("Addcode not in server for: " + addCode + ", " + ssid + "," + name);
                    responseBuilder.setRc(1);
                } else if (request_addcode_map.get(addCode).getSsid()!=ssid) {
                    //if ssid does not match addcode, return error
                    System.out.println("ssid does not match: " + addCode + ", " + ssid + "," + name);
                    responseBuilder.setRc(2);
                } else {
                    //ssid matches and is valid, fulfill request
                    System.out.println("ssid matched and valid for: " + addCode + ", " + ssid + "," + name);
                    String courseName = request_addcode_map.get(addCode).getCourse();
                    //If map entry doesn't have list, add new list
                    if (course_regrequest_map.get(courseName)==null) course_regrequest_map.put(courseName, new ArrayList<>());
                    course_regrequest_map.get(courseName).add(request);
                    responseBuilder.setRc(0);
                }

                //Build and send response
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                var response = responseBuilder.build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();
            }
            @Override
            public void list(Messages.ListRequest request, StreamObserver<Messages.ListResponse> responseObserver) {
                var responseBuilder = Messages.ListResponse.newBuilder();

                var course = request.getCourse();
                if (!validCourses.contains(course)) {
                    responseBuilder.setRc(1);
                } else if (course_regrequest_map.get(course)!=null) {
                    for (RegisterRequest rr : course_regrequest_map.get(course)) {
                        responseBuilder.addRegisterations(rr);
                    }
                }

                //Build and send response
                try {
                    Thread.sleep(500);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
                var response = responseBuilder.build();
                responseObserver.onNext(response);
                responseObserver.onCompleted();
            }
        }

        try {
            var server = ServerBuilder.forPort(port).addService(new HelloImpl()).build();
            server.start();
            server.awaitTermination();
        } catch (IOException e) {
            System.out.println("couldn't serve on " + port);
        }
        return 0;
    }
    public static void main(String[] args) {
        System.exit(new CommandLine(new Main()).execute(args));
    }
}